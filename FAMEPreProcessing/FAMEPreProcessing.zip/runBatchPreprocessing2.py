
import os
import zipfile
import arcpy
import glob
import re
#import pandas
# Function to delete all parts of a shapefile
def delete_shapefile(directory, shapefile_name):
    # remove path from shapefile_name if required
    shapefile_name = str(os.path.split(shapefile_name)[1])
    
    # make full path including directory
    shapefile = os.path.join(directory, shapefile_name)
    
    # find all parts of the shapefile
    files = glob.glob(os.path.splitext(shapefile)[0] + '.*')
    # and delete them
    for file in files:
      os.remove(file)


#path to zipped individual fire scenarios
zipPath = "./testZip" #"C:/Users/na03/OneDrive - Department of Environment, Land, Water and Planning/outputs"

#path for working directory( other paths relative to this)
wdpath= "D:/FAMEshiny/FAMEPreProcessing"
os.chdir(wdpath)
FIRE_HISTORY = "./commondata/SimpleFireHistory.shp"
tempPath ="./temp/"

clip_polygons="./commondata/SimpleAnalysisArea.shp" #"./commondata/LF_DISTRICT.shp"
if not os.path.exists('rawFH.gdb'):
  arcpy.CreateFileGDB_management(wdpath, 'rawFH.gdb')
arcpy.env.workspace = 'rawFH.gdb'


if  not os.path.isdir("outputs") :
  os.mkdir("outputs")

if not os.path.exists('scratch.gdb'):
  arcpy.CreateFileGDB_management(wdpath, "scratch.gdb")
  
arcpy.env.scratchWorkspace = 'scratch.gdb'
arcpy.env.overwriteOutput = True


FAMEv2_1 = arcpy.AddToolbox("./FAMEv2_1.tbx")


FAME_Zipped_Scenarios = []

for root, dirs, files in os.walk(zipPath):
	for file in files:
	  if(file.endswith("FAME.zip")):
		  FAME_Zipped_Scenarios.append(os.path.join(root,file))

		  
for name in FAME_Zipped_Scenarios:
  
  myzip = zipfile.ZipFile(name, mode="r")
  myzip.namelist()
  myzip.extractall(path= tempPath)
  myFHFile =[f for f in myzip.namelist() if f.endswith(".shp")][0]
  FIRE_FUTURE = tempPath + myFHFile
  Output_Shapefile = "./outputs/rawFH" + myFHFile
  outputGDBFC = "rawFH" + re.sub(".shp","",myFHFile)
  try:
    FAMEv2_1.FireHistoryandScenarioand1755(FIRE_HISTORY = FIRE_HISTORY,FireScenario = FIRE_FUTURE,Clip_to_this_polygon = clip_polygons,Output_Path = outputGDBFC)
  except:
    print("Could not make FireHistoryandScenarioand1755 for "  + myFHFile)
  try:
    arcpy.management.CopyFeatures(in_features = "rawFH.gdb/" + outputGDBFC,  out_feature_class = Output_Shapefile)
  except:
    print("could mot output shapefile to " + Output_Shapefile)
  delete_shapefile(directory=tempPath, shapefile_name = myFHFile)
  #
  del (FIRE_FUTURE,outputGDBFC,Output_Shapefile,myFHFile,myzip)
  print(name + " DONE")
